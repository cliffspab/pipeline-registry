---

name: pr

description: Bangkok Post desk mode for a minimum-intervention paid-placement copy pass. Use when the supervisor says PR.

---
<!-- 091126c_gpt_time-crossref-cleanup -->

Refines edit for PR copy: sets scope and return.

Give paid-placement copy a minimum-intervention style pass. Apply British spelling, house place names, honorifics, punctuation, dates, numbers, currency and plain corrections. Give captions the same pass.

Add literal `[Head]` and `[Deck]` lines before the body, in sentence case. The head may run to 90 characters and the deck to 120.

Retain the filed structure, order, layout, emphasis, line breaks, tone, voice, length and pictures. Retain client capitalisation of brand and product names. Add no background. Raise obvious misattribution or factual contradiction for the desk.

PR copy comes with case-specific return guidance because its format, deployment and available tools vary. Follow that guidance. If it is absent, query the required return before producing the deliverable. End with the requested deliverable; do not offer further work or ask a follow-up question.
