---
name: check
description: Fast Bangkok Post check of a DC-X task the chief sub has already read, or a QC review of another operator's Job Report. Use when the supervisor says check, check only or qc, or gives a slug from the Output view for initialling.
---

# [P4] PAGE CHECKS AND QC

Runs on `[G1-A] HOUSE ESSENTIALS` and on `edit`, which is in context for the session. This file sets scope and return.

`QC` is the Check use for another operator's Job Report. Confirm the facts are correct and Bangkok Post style has been applied. List the changes required and await guidance; do not rewrite the report or its copy. If no change is required, return `Clear to initial.`

- Read the pasted task: head, deck, byline, body, captions and counters. A check returns no copy.
- Everything on the page is in scope, but report only what needs action: mistaken identity, misattribution, factual or internal contradictions, names and name forms, titles, figures and arithmetic, dates against publication day, legal hedges, naming traps, material house-style errors, genuine spatial problems, weak or inaccurate furniture, and anything missing (head, required deck, copy, caption, credit). Treat spatial issues as perceived unless the page supplies a reliable measurement. Style the chief has already passed stands.
- Head and deck stay unless there is a real mistake or a clear inspiration.
- A style fix is included only if it maintains the existing footprint.
- Check `addendum.doc` first when it is in context. Search a material fact you would change, or one the copy gives reason to doubt; nothing else, and nothing in copy from a mainstream global news organisation `[P2]`. A fact change needs two independent sources under `[P2]` (or cites the addendum's recorded verification sources). If the sources cannot settle it, leave the printed fact unchanged and add a `Query:` line; if the printed fact itself appears unsafe, mark the query `HOLD`. A HOLD raised here remains open and joins the next EDIT's `OUTSTANDING` list until the supervisor resolves it. A mononym, nickname or single name alone is not a search trigger.

## Return

Either Clear to initial. or:

Fact

1. [field, para] "old" > "new" — source 1; source 2

Major

2. [field, para] "old" > "new" (why, in five words)

House

3. ...

Must fix: 1, 2

Query: ...

Fact items lead, with both sources. Numbered, exact strings, nothing else. No preamble, alternates, style log, offer of further work or follow-up question.
